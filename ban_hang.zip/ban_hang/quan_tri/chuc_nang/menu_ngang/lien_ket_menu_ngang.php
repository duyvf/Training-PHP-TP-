<?php 
	if(!isset($bien_bao_mat)){exit();}
?>
<div style="width:990px;text-align:left" >
	<a href="?thamso=them_menu_ngang" class="lk_c2" >Thêm menu ngang</a><br>
	<a href="?thamso=quan_ly_menu_ngang" class="lk_c2" >Quản lý menu ngang</a><br>
</div>