<?php 
	if(!isset($bien_bao_mat)){exit();}
?>
<div style="width:990px;text-align:left" >
	<a href="?thamso=them_slideshow" class="lk_c2" >Thêm ảnh slideshow</a><br>
	<a href="?thamso=quan_ly_slideshow" class="lk_c2" >Quản lý slideshow</a><br>
</div>