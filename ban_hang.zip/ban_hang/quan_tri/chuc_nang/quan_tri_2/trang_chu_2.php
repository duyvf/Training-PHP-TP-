<?php 
	if(!isset($bien_bao_mat)){exit();}
?>
<style type="text/css" >
	a.lk_2{text-decoration:none;color:black;font-size:22px;line-height:30px;}
	a.lk_2:hover{color:red;}
</style>
<table width="990px" >
	<tr>
		<td width="495px" valign="top" >
			<a href="?thamso=them_menu_ngang" class="lk_2" >Thêm menu ngang</a><br>
			<a href="?thamso=them_menu_doc" class="lk_2" >Thêm menu dọc</a><br>
			<a href="?thamso=them_san_pham" class="lk_2" >Thêm sản phẩm</a><br>
		</td>
		<td width="495px" valign="top" >
			<a href="?thamso=quan_ly_menu_ngang" class="lk_2" >Quản lý menu ngang</a><br>
			<a href="?thamso=quan_ly_menu_doc" class="lk_2" >Quản lý menu dọc</a><br>
			<a href="?thamso=quan_ly_san_pham" class="lk_2" >Quản lý sản phẩm</a><br>
			<a href="?thamso=hoa_don" class="lk_2" >Quản lý hóa đơn</a><br><br><br>
		</td>
	</tr>
	<tr>
		<td valign="top" >
			<a href="?thamso=san_pham_trang_chu" class="lk_2" >Sản phẩm trang chủ</a><br>
			<a href="?thamso=san_pham_noi_bat" class="lk_2" >Sản phẩm nổi bật</a><br>
			<a href="?thamso=slideshow" class="lk_2" >Slideshow</a><br>
		</td>
		<td valign="top" >
			<a href="?thamso=sua_banner" class="lk_2" >Thay đổi banner</a><br>
			<a href="?thamso=sua_footer" class="lk_2" >Thay đổi footer</a><br>
			<a href="?thamso=sua_quang_cao_trai" class="lk_2" >Thay đổi quảng cáo trái</a><br>
			<a href="?thamso=sua_quang_cao_phai" class="lk_2" >Thay đổi quảng cáo phải</a><br>
			<a href="?thamso=sua_thong_tin_quan_tri" class="lk_2" >Thay đổi thông tin quản trị</a><br>
		</td>
	</tr>
</table>