<?php
    $con=mysqli_connect("localhost","root","");
   mysqli_select_db($con, "banhang1");
    mysqli_query($con,'SET NAMES "UTF8"');
?> 